<?php include 'includes/header.php'; ?>
<div class="container">
    <h1>Welcome to the E-Learning Platform</h1>
    <p><a href="login.php">Login</a> or <a href="register.php">Register</a> to start learning.</p>
</div>
<?php include 'includes/footer.php'; ?>
